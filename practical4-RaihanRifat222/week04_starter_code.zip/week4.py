
def call_counts(path):
    """Return a dictionary with the counts of samples from each label name
    >>> call_counts('sample_cifar10')
    {'ship': 8, 'frog': 6, 'cat': 6, 'automobile': 6, 'deer': 6, 'bird': 9, 'airplane': 10, 'truck': 4, 'dog': 8, 'horse': 3}
    """
    return {}

def sample_images(path, label_name):
    """Return a list of tuples (filename, label_name) that lists all file names in the path that belong to class 
    label_name
    >>> sample_images("sample_cifar10", "horse")
    [('sample_cifar10/7_4207.png', 'horse'), ('sample_cifar10/7_4197.png', 'horse'), ('sample_cifar10/7_4202.png', 'horse')]
    """
    return []


def sample_image_folder(path, selected_label_names, sample_numbers, output_filenames):
    """For each number n listed in sample_numbers, return the name of a CSV file that stores the first n 
    samples from each label name specified by exploring the image files stored in path.
    >>> sample_image_folder('sample_cifar10', ('deer', 'airplane', 'truck'), (2, 1), ('file1.csv', 'file2.csv'))
    ['file1.csv', 'file2.csv']
    """
    result = []
    start = 0
    for i, n in enumerate(sample_numbers):
        selected_image_files = []
        for l in selected_label_names:
            image_files = sample_images(path, l)
            selected_image_files += image_files[start:start+n]

        start = start+n
        filename = output_filenames[i]
        lines = ["%s,%s\n" % fname for fname in selected_image_files]
        with open(filename, "w") as f:
            f.writelines(lines)
        result.append(filename)
    return result

if __name__ == "__main__":
    import doctest
    doctest.testmod()
